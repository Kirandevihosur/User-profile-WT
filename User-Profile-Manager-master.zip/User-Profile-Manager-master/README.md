# MEAN stack project

- [MongoDB](http://www.mongodb.org/)
- [Express](http://expressjs.com/)
- [AngularJS](https://angularjs.org/)
- [Node.js](http://nodejs.org)
- [Satellizer](https://github.com/sahat/satellizer)


# Steps:
- Navigate to client
## Commands
- `npm install`
- `npm start`

- Open the browser to `localhost:1337`
